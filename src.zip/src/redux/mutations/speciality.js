import specialitySlice from "../slices/speciality";

export default specialitySlice.actions