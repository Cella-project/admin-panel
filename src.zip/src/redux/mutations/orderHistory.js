import orderHistorySlice from "../slices/orderHistory";

export default orderHistorySlice.actions