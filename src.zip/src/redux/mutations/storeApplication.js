import storeApplicationSlice from "../slices/storeApplication";

export default storeApplicationSlice.actions