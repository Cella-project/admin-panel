import stickySlice from "../slices/sticky";

export default stickySlice.actions;