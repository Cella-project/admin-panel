import driverApplicationSlice from "../slices/driverApplication";

export default driverApplicationSlice.actions