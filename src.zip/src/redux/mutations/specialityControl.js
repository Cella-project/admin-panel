import specialityControlSlice from "../slices/specialityControl";

export default specialityControlSlice.actions