import authSlice from '../slices/auth';

export default authSlice.actions;