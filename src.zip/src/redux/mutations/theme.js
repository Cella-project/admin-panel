import themeSlice from "../slices/theme";

export default themeSlice.actions