import popupSlice from '../slices/popup';

export default popupSlice.actions;