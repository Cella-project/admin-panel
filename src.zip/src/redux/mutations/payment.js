import paymentSlice from "../slices/payment";

export default paymentSlice.actions;