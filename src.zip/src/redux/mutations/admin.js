import adminSlice from "../slices/admin";

export default adminSlice.actions