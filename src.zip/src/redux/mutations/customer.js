import customerSlice from "../slices/customer";

export default customerSlice.actions