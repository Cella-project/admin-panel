import driverSlice from "../slices/driver";

export default driverSlice.actions