import storeSlice from "../slices/store";

export default storeSlice.actions