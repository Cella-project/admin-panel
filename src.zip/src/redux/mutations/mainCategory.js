import mainCategorySlice from "../slices/mainCategory";

export default mainCategorySlice.actions