import productSlice from "../slices/product";

export default productSlice.actions