import subCategorySlice from "../slices/subCategory";

export default subCategorySlice.actions