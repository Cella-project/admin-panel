import { useParams } from "react-router-dom";
import React, { useEffect, useState } from "react";
import Popup from "../../../components/common/PopupForm";
import GreenCard from "../../../components/common/GreenCard";
import { useSelector, useDispatch } from 'react-redux';
import SpecialityCard from "../../../components/speciality/SpecialityCard";
import SpecialityColorLists from "../../../components/speciality/SpecialityColorLists";
import SpecialityTagLists from "../../../components/speciality/SpecialityTagLists";
import SpecialityMaterialLists from "../../../components/speciality/SpecialityMaterialLists";

import { specialityActions, specialityControlActions } from '../../../apis/actions';
import { specialityMutations, specialityControlMutations } from '../../../redux/mutations';
import './SpecialityControl.scss'
import Loading from "../../../components/global/Loading";

const SpecialityControl = () => {
    const params = useParams();
    const dispatch = useDispatch();
    const specialitys = useSelector(state => state.speciality.specialitys);
    const specialityData = useSelector(state => state.speciality.specialityData);
    const colors = useSelector(state => state.specialityControl.colors);
    const tags = useSelector(state => state.specialityControl.tags);
    const materials = useSelector(state => state.specialityControl.materials);
    const [popupShown, setPopupShown] = useState(false);
    const [header, setHeader] = useState('');


    useEffect(() => {
        dispatch(specialityMutations.setSpecialitys(null));
        dispatch(specialityActions.getSpecialitys());
        dispatch(specialityMutations.setSpecialityData(null));
        dispatch(specialityActions.getSpecialityData(params.id));
        dispatch(specialityControlMutations.setColors(null));
        dispatch(specialityControlMutations.setTags(null));
        dispatch(specialityControlMutations.setMaterials(null));
        dispatch(specialityControlActions.getColors(params.id));
        dispatch(specialityControlActions.getTags(params.id));
        dispatch(specialityControlActions.getMaterials(params.id));
    }, [dispatch, params.id]);


    useEffect(() => {
        if (specialityData) {
            specialityData && (document.title = `${specialityData.title} • Speciality Control • Admin Panel`);
        }
    }, [specialityData]);


    const addColor = () => {
        setPopupShown(true);
        setHeader('Add Speciality Color');
        document.getElementById('dashboard-view').style.zIndex = 60;
        const TopScroll = window.pageYOffset || document.documentElement.scrollTop;
        const LeftScroll = window.pageXOffset || document.documentElement.scrollLeft;
        window.onscroll = () => {
            window.scrollTo(LeftScroll, TopScroll);
        };
    }
    const addTag = () => {
        setPopupShown(true);
        setHeader('Add Speciality Tag');
        document.getElementById('dashboard-view').style.zIndex = 60;
        const TopScroll = window.pageYOffset || document.documentElement.scrollTop;
        const LeftScroll = window.pageXOffset || document.documentElement.scrollLeft;
        window.onscroll = () => {
            window.scrollTo(LeftScroll, TopScroll);
        };
    }
    const addMaterial = () => {
        setPopupShown(true);
        setHeader('Add Speciality Material');
        document.getElementById('dashboard-view').style.zIndex = 60;
        const TopScroll = window.pageYOffset || document.documentElement.scrollTop;
        const LeftScroll = window.pageXOffset || document.documentElement.scrollLeft;
        window.onscroll = () => {
            window.scrollTo(LeftScroll, TopScroll);
        };
    }

    let content = <Loading />;

    if (specialitys && specialityData && specialityData !== null) {
        content = (
            <>
                <div className="full-width flex-row-left-start2col">
                    {
                        specialitys && specialityData && specialitys.filter((speciality) =>
                            speciality._id === specialityData._id
                        ).map((speciality) => (
                            <SpecialityCard key={speciality._id} speciality={speciality} />
                        ))
                    }
                </div>
                <div className="full-width flex-row-left-start2col">
                    <div className="flex-row-top-between2col full-width">
                        <GreenCard title="Colors" icon={'bi bi-plus-circle'} iconClickHandle={addColor}>
                            {colors &&
                                colors !== null ? colors.map((color) =>
                                    <SpecialityColorLists color={color} key={color._id} />
                                ) : <Loading />
                            }
                        </GreenCard>

                        <GreenCard className="speciality-control--tags full-width flex-row-center margin-6px-H flex-wrap" title="Tags" icon={'bi bi-plus-circle'} iconClickHandle={addTag}>
                            {tags &&
                                tags !== null ? tags.map((tag) =>
                                    <SpecialityTagLists tag={tag} key={tag._id} />
                                ) : <Loading />
                            }
                        </GreenCard>

                        <GreenCard className="speciality-control--tags full-width flex-row-center margin-6px-H flex-wrap" title="Materials" icon={'bi bi-plus-circle'} iconClickHandle={addMaterial}>
                            {materials &&
                                materials !== null ? materials.map((material) =>
                                    <SpecialityMaterialLists material={material} key={material._id} />
                                ) : <Loading />
                            }
                        </GreenCard>

                    </div>
                </div>

            </>
        )
    }

    return (
        <div className="speciality-control--container full-width flex-col-left-start2col">
            {popupShown &&
                <Popup popupToggle={setPopupShown} header={header} data={specialityData} />
            }
            <div className="main-category--braud-cramb gray inter size-16px font-bold">
                {(specialityData && specialityData !== null) && ('Specialties > ' + specialityData.title + ' / Speciality Control')}
            </div>
            {content}
        </div >
    );
};

export default SpecialityControl;