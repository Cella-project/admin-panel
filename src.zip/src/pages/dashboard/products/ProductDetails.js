import React, { useEffect } from "react";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";
import PerfectScrollbar from "react-perfect-scrollbar";

import GreenCard from "../../../components/common/GreenCard";
import ProductInfo from "../../../components/products/ProductInfo";
import ProductControl from "../../../components/products/ProductControl";

import "./ProductDetails.scss";

import { useDispatch, useSelector } from "react-redux";
import { productActions } from "../../../apis/actions";
import { productMutations } from "../../../redux/mutations";


const ProductDetails = () => {
  const params = useParams();
  const product = useSelector((state) => state.product.productData);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(productMutations.setProductData(null));
    dispatch(productActions.getProductData(params.id));
  }, [dispatch, params.id]);
  let editmode = false;

  product && (document.title = `${product.title} • Admin Panel`);

  let cards = [
    { title: 'Quantitiy', content: 0, icon: "bi bi-box-seam" },
    { title: '# of orders', content: 0, icon: "bi bi-box-seam" },
    { title: 'Success Orders', content: 0, icon: "bi bi-box-seam" },
    { title: 'returned orders', content: 0, icon: "bi bi-box-seam" },
  ];
  if (product && product !== null) {
    cards = [
      { title: 'Quantity', content: product.avilableQuantity, icon: "bi bi-box-seam" },
      { title: '# of Orders', content: 0, icon: "bi bi-box-seam" },
      { title: 'Success Orders', content: 0, icon: "bi bi-box-seam" },
      { title: 'Returned Orders', content: 0, icon: "bi bi-box-seam" },
      // { title: '# of orders', content: product.orders.length, icon: "bi bi-box-seam" },
      // { title: 'Success Orders', content: product.orders.filter((order) => order.status === 'Delivered').length, icon: "bi bi-box-seam" },
      // { title: 'returned orders', content: product.orders.filter((order) => order.status === 'Returned').length, icon: "bi bi-box-seam" },
    ];
  }
  const hasDiscount = product?.discount?.hasDiscount;


  return (
    <div className="product-details--container full-width flex-col-left-start2col">
      {product && (
        <>
          <div className="flex-row-left-start2col product-details full-width">
            <div className="width-90-100 product-details">
              <ProductInfo
                product={product} editmode={editmode}
              />
            </div>
            <div className="flex-row-between product-details width-10-100">
              <ProductControl id={product._id}/>
            </div>
          </div>
          {
            product.tags.length > 0 &&
            <PerfectScrollbar options={{ axis: 'x' }} className="product-details--scroll--cont shadow-2px inter radius-15px white-bg full-width">
              <div className="product-details--tags flex-row-between full-width">
                {product.tags.map((tag, index) => {
                  return (
                    <div className="product-details--tags--tag flex-row-center size-12px radius-15px margin-8px-H text-shadow lavender-bg" key={index}>
                      {tag.tag}
                    </div>
                  );
                })
                }
              </div>
            </PerfectScrollbar>
          }

          <div className="full-width">
            <div className="full-width flex-row2col">
              {
                cards.map((card, index) => {
                  return (
                    <GreenCard title={card.title} key={index}>
                      <div className="full-width flex-row-center">
                        <i className={`${card.icon} mint-green size-30px`}></i>
                        <p className="gray inter size-28px margin-12px-H text-shadow">{card.content}</p>
                      </div>
                    </GreenCard>
                  );
                })
              }
            </div>
          </div>
          <div className="full-width">
            <div className="full-width flex-row-between">
              <GreenCard title="Sizes">
                {
                  product.sizes.map((size, index) => (
                    <div key={index} className="product-details--sizes flex-col-center ">
                      <div className="mint-green-bg radius-15px white flex-row-center">
                        <div className="product-details--sizes--quantity white-bg gray radius-15px">{size.quantity} Available</div>
                        <div className="product-details--sizes--size font-bold size-20px ">{size.size}</div>
                      </div>
                    </div>
                  ))
                }
              </GreenCard>
              <GreenCard title="Colors">
                {product.colors.map((color, index) => (
                  <div key={index} className="product-details--colors flex-col-center ">
                    <div className="mint-green-bg radius-15px white flex-row-center">
                      <div className="product-details--colors--quantity white-bg gray radius-15px">{color.quantity} Available from </div>
                      <div style={{ backgroundColor: color.hexCode }} className="product-details--colors--color size-20px radius-circular"></div>
                    </div>
                  </div>
                ))}
              </GreenCard>
              {
                hasDiscount &&
                <GreenCard title="Discount">
                  <div className="product-details--discount flex-row-center">
                    <div className="product-details--discount--content flex-col-center">
                      <p className="gray inter size-28px margin-12px-H text-shadow">{product.discount.discountAmount}{product.discount.discountType==='Percentage' &&<i className="bi bi-percent"></i>}</p>
                      <p className="gray inter margin-12px-H text-shadow">{product.discount.discountType}</p>
                    </div>
                  </div>
                </GreenCard>
              }

            </div>
          </div>

          <div className="full-width flex-row-center">
            <GreenCard title="Reviews">
              <Link to={`/Reviews`} className="pointer lists-card--link">
                <i className="bi bi-arrow-right flex-row-right-start"></i>
              </Link>
            </GreenCard>
          </div>
        </>)
      }
    </div>
  );
};
export default ProductDetails;
