import axios from "axios";

export default axios.create({
    baseURL: "http://143.244.196.79:4012/",
});